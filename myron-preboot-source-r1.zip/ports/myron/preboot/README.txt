MYRON / K90 Pro Max preboot diagnostic r1

用途
读取 ABL 在启动时传入的设备树，显示 RAM bank、reserved-memory、
FDT reserve map、initrd 范围，以及显示管线的 framebuffer 地址、stride、
format、unpack、CPU 页大小能力。屏幕上的数字均为十六进制。
这是参数采集程序，不是 iOS 镜像，也不运行 XNU。

使用（仅限已经解锁 bootloader 的 myron）
1. 解压完整构建包，安装 Python 3，确保 Google platform-tools 的 fastboot 在 PATH。
2. 手机进入 bootloader fastboot；电脑只连接这一台 fastboot 手机。
3. 在解压目录执行：python boot_once.py
   脚本验证镜像 SHA256、product=myron、is-userspace=no、unlocked=yes，
   然后只执行 fastboot boot。不会执行 flash、erase、unlock、set_active。
4. 用另一部手机拍摄完整屏幕视频，至少覆盖 PAGE 01 到最后一页。
   每页 8 秒，共两轮，然后请求 PSCI 重启。最长约 6 分钟。
5. 发回视频或各页清晰照片、fastboot 返回的成功/失败文字，
   并注明色条是否从左到右为红、绿、蓝、白。
   分享前遮住终端中的设备序列号，不必重新采集此前的 Android 日志。

若没有显示
- 参数或格式检查失败会请求立即重启。空白画面不算参数验证通过。
- 若 fastboot 返回 unknown command / boot unsupported / image rejected，
  保留错误文字停止；不要改用 fastboot flash。
- 若黑屏停住未自动重启，可长按电源键恢复；不承诺固件一定响应 PSCI。
- 本镜像尚无 MYRON 真机启动验证，QEMU 仅覆盖入口和设备树读取流程。

范围与限制
- 不加载存储、触摸或 USB 驱动，不写 UFS；会写自身 RAM 和经过检查的 splash buffer。
- 拒绝 Pandora 屏幕参数回退；不做 RAM 探写；不切换 SMMU，不重编程显示管线。
- 只接受 live DT 中的 p11u/FocalTech 标识、MDP 基址/SSPP 偏移和 splash 区间
  与固定 EvoX 参考一致，且寄存器报告 1200x2608、线性紧密排列 4x8-bit 像素。
- 即使通过边界检查，寄存器地址仍可能是 IOVA 或闲置管线；只有看到画面和
  翻页才能佐证显示接管成功。不会据此直接把 RAM 写入 XNU 配置。
- RAM 是固件描述，不等于可安全分配区。动态保留区只报告数量；安全选区还须
  排除保留区、bootloader handoff 对象、诊断镜像和未来 payload。
- 此版通过拍照采集内存条目，不导出完整 runtime DTB。后续设备树生成器需要
  完整 runtime DTB 或另行验证的、完整的 handoff 证据导入路径。

来源与复现
- entry / font / renderer / boot-v4 packer 基于 ShueiTsuki/ios-pandora
  d338ef09c93ba7e69d03e997478fe3ad3acda309 的 shim/hello 与 tools。
  https://github.com/ShueiTsuki/ios-pandora
- EvoX myron prebuilt: 9999f765b53876bf7a013a4fde5221153ad570fc
  device tree: 941665af189930742a02deb258583ec697a7e8ec
  common tree: c542281a7bb0c7d8b5f6b1a9130edd0fa0e052e9
- 格式位字段参考 Qualcomm SDE 的 sde_hw_sspp_setup_format：
  https://android.googlesource.com/kernel/msm/+/d066b4b959a95fd4686754ee82a7c6d21466b27c/drivers/gpu/drm/msm/sde/sde_hw_sspp.c
  属于沿用该寄存器布局的假设，真机画面仍待验证。
- 构建：bash build.sh（clang、lld、llvm-objcopy、readelf、Python 3）
- 测试：python3 tests/test_core.py
- QEMU 测试专用 Image 不能作为手机镜像发布。
- 不包含 Apple SDK、KDK、iOS 固件或 XNU 二进制。
