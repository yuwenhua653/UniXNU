"""Validate this package and the attached target, then temporary fastboot boot.
Requires Python 3 and Google's platform-tools in PATH. No automatic unlocking.
"""
import hashlib, json, re, subprocess, sys
from pathlib import Path

def run(*args):
    p=subprocess.run(['fastboot',*args],text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=90)
    if p.returncode: raise RuntimeError(p.stdout.strip())
    return p.stdout

def main():
    here=Path(__file__).resolve().parent
    image=here/'myron-preboot-diag.img'
    expected=json.loads((here/'build-manifest.json').read_text())['sha256'][image.name]
    if hashlib.sha256(image.read_bytes()).hexdigest()!=expected:raise RuntimeError('Image checksum mismatch')
    devices=[s for s in run('devices').splitlines() if re.search(r'\sfastboot\s*$',s)]
    if len(devices)!=1:raise RuntimeError('Connect exactly one phone in bootloader fastboot mode')
    serial=devices[0].split()[0]
    product=run('-s',serial,'getvar','product')
    if not re.search(r'(?:\(bootloader\)\s*)?product:\s*myron\s*$',product,re.M|re.I):
        raise RuntimeError('Target product is not myron; refusing to boot')
    mode=run('-s',serial,'getvar','is-userspace')
    if not re.search(r'is-userspace:\s*no\s*$',mode,re.M|re.I):raise RuntimeError('Use bootloader fastboot, not fastbootd')
    unlocked=run('-s',serial,'getvar','unlocked')
    if not re.search(r'unlocked:\s*(?:yes|true)\s*$',unlocked,re.M|re.I):raise RuntimeError('An already-unlocked bootloader is required; this script will not unlock it')
    print('MYRON verified. Record the screen with another phone now. Temporary boot only.')
    print(run('-s',serial,'boot',str(image)))
if __name__=='__main__':
    try:main()
    except (RuntimeError,OSError,subprocess.TimeoutExpired) as e:sys.exit(str(e))
