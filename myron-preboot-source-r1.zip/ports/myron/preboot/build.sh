#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
out="${1:-out}"
mkdir -p "$out"
flags=(-g0 -O2 -ffreestanding -fno-builtin -nostdlib -fno-pic -fno-stack-protector
       -mgeneral-regs-only -mstrict-align -Wall -Wextra -Werror)
if [[ ${DIAG_QEMU_TEST:-0} == 1 ]]; then flags+=(-DDIAG_QEMU_TEST=1); fi
if [[ -n ${ZIG:-} ]]; then
  cc=("$ZIG" cc -target aarch64-freestanding-none -mcpu=generic-neon-fp_armv8+strict_align)
  link=("$ZIG" cc -target aarch64-freestanding-none -nostdlib -static -Wl,-T,hello.ld -Wl,-e,_head -Wl,--build-id=none)
  objcopy=("$ZIG" objcopy)
else
  cc=(clang --target=aarch64-none-elf)
  link=(ld.lld -T hello.ld --build-id=none)
  objcopy=(llvm-objcopy)
fi
for source in start.S hello.c core.c; do
  "${cc[@]}" "${flags[@]}" -c "$source" -o "$out/${source%.*}.o"
done
if readelf -r "$out/hello.o" "$out/core.o" | grep -q R_AARCH64_ABS; then
  echo 'Refusing absolute C relocations' >&2; exit 1
fi
"${link[@]}" "$out/start.o" "$out/hello.o" "$out/core.o" -o "$out/diagnostic.elf"
"${objcopy[@]}" -O binary "$out/diagnostic.elf" "$out/Image"
python3 mkbootimg_v4.py "$out/Image" "$out/myron-preboot-diag.img"
python3 verify_image.py "$out"
