#ifndef MYRON_DIAG_CORE_H
#define MYRON_DIAG_CORE_H
#include <stdint.h>
#define MAX_DTB (4u * 1024 * 1024)
#define MAX_RECORDS 256
struct range { uint64_t base, size; char name[32]; unsigned kind; };
struct report {
    struct range ranges[MAX_RECORDS];
    unsigned count, banks, dynamic_reserved, zero_banks;
    uint32_t dtb_size, crc, pipes[10];
    uint64_t splash, splash_size, mdp;
    unsigned panel, touch, mdp_ok, splash_ok;
};
/* kind: 1 RAM, 2 reserved-memory, 3 FDT reserve map, 4 initrd. */
int parse_dtb(const uint8_t *data, uint32_t len, struct report *out);
struct pipe { uint32_t size, addr, stride, fmt, unpack, opmode, faulted; };
int valid_pipe(const struct report *r, const struct pipe *p);
uint32_t pixel(const struct pipe *p, uint32_t rgb);
uint32_t myron_crc32(const uint8_t *p, uint32_t n);
#endif
