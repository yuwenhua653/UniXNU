/* MYRON bootloader handoff diagnostic. Rendering and entry are adapted from
 * ShueiTsuki/ios-pandora d338ef09 shim/hello. No storage or USB drivers. */
#include "core.h"
#include "font.h"
uint32_t safe_rd32(uint64_t pa, uint32_t *faulted);
void fatal(void) __attribute__((noreturn));
#define REG(r) ({uint64_t v; __asm__ volatile("mrs %0, " #r : "=r"(v)); v;})
static uint8_t blob[MAX_DTB] __attribute__((aligned(8)));
static struct report report;
static struct pipe pipes[10];
static struct pipe *active;
static unsigned row;
static uint32_t white, green, bg;
static uint64_t dtb_pa, load_pa, level;
extern char _image_end[];
static uint64_t freq;
/* Freestanding compiler support; no libc or Apple components. */
void *memcpy(void *dst, const void *src, unsigned long n) {
    uint8_t *a=dst; const uint8_t *b=src; while(n--) *a++=*b++; return dst;
}
void *memset(void *dst, int c, unsigned long n) {
    uint8_t *a=dst; while(n--) *a++=(uint8_t)c; return dst;
}
static void fill(unsigned x, unsigned y, unsigned w, unsigned h, uint32_t color) {
    volatile uint32_t *fb=(volatile uint32_t *)(uintptr_t)active->addr;
    unsigned stride=(active->stride&65535)/4;
    for(unsigned j=y;j<y+h && j<2608;j++)
        for(unsigned i=x;i<x+w && i<1200;i++) fb[j*stride+i]=color;
    __asm__ volatile("dsb sy" ::: "memory");
}
static void text(const char *s, uint32_t color) {
    unsigned col=0;
    for(;*s && col<48;s++,col++) {
        unsigned ch=(unsigned char)*s; if(ch<32 || ch>126) ch='?';
        const uint8_t *g=font8x16[ch-32];
        for(unsigned y=0;y<16;y++) for(unsigned x=0;x<8;x++)
            if(g[y]&(128>>x)) fill(24+col*24+x*3,24+row*48+y*3,3,3,color);
    }
    row++;
}
static char *cat(char *p,const char *s) { while(*s)*p++=*s++;*p=0;return p; }
static char *hex(char *p,uint64_t v,unsigned n) {
    for(unsigned i=n;i;i--) {unsigned d=(v>>((i-1)*4))&15;*p++=d<10?'0'+d:'A'+d-10;}*p=0;return p;
}
static void val(const char *key,uint64_t v) {char b[80];hex(cat(b,key),v,16);text(b,white);}
static int overlaps(uint64_t a,uint64_t n,uint64_t b,uint64_t m) {return a<b+m && b<a+n;}
static unsigned device_ok(void) {
    static const uint32_t offsets[10]={0x2c000,0x35000,0x3e000,0x47000,0x98000,0xa1000,0xaa000,0xb3000,0xbc000,0xc5000};
    if(!report.panel || !report.touch || !report.mdp_ok || !report.splash_ok ||
       report.mdp!=0x9800000 || report.splash!=0xfc800000 || report.splash_size!=0x2b00000) return 0;
    for(unsigned i=0;i<10;i++) if(report.pipes[i]!=offsets[i]) return 0;
    return 1;
}
static void find_fb(void) {
    static const uint32_t regs[6]={0,0x14,0x24,0x30,0x34,0x38};
    for(unsigned i=0;i<10;i++) {
        uint32_t values[6], fault=0;
        for(unsigned j=0;j<6;j++) {uint32_t f=0;values[j]=safe_rd32(report.mdp+report.pipes[i]+regs[j],&f);fault|=f;}
        struct pipe p={values[0],values[1],values[2],values[3],values[4],values[5],fault};
        pipes[i]=p;
        if(!valid_pipe(&report,&p)) continue;
        uint64_t span=(uint64_t)(p.stride&65535)*(p.size>>16);
        if(overlaps(p.addr,span,load_pa,(uintptr_t)_image_end-load_pa) ||
           overlaps(p.addr,span,dtb_pa,report.dtb_size)) continue;
        /* Multiple different candidates are ambiguous: do not guess. */
        if(active && (active->addr!=p.addr || active->stride!=p.stride || active->fmt!=p.fmt || active->unpack!=p.unpack)) fatal();
        active=&pipes[i];
    }
    if(!active) fatal();
    white=pixel(active,0xffffff);green=pixel(active,0x40ff40);bg=pixel(active,0x102040);
}
static void page(unsigned index,unsigned pages,unsigned seconds) {
    fill(0,0,1200,2608,bg);row=0;char b[80],*p;
    text("MYRON HANDOFF DIAG r1",green);
    p=hex(cat(b,"PAGE "),index+1,2);p=hex(cat(p,"/"),pages,2);hex(cat(p,"  SECONDS LEFT 0x"),seconds,3);text(b,white);
    text("Film all pages. All numbers hexadecimal.",white);
    p=hex(cat(b,"DTB CRC32 "),report.crc,8);hex(cat(p," BYTES "),report.dtb_size,8);text(b,white);
    row++;
    if(!index) {
        val("EL       ",level);val("LOADED   ",load_pa);val("DTB      ",dtb_pa);
        val("MIDR     ",REG(midr_el1));val("MPIDR    ",REG(mpidr_el1));
        val("MMFR0    ",REG(id_aa64mmfr0_el1));val("CNTFRQ   ",freq);
        row++; val("FB BASE  ",active->addr);val("FB SIZE  ",active->size);
        val("FB STRIDE",active->stride);val("FB FORMAT",active->fmt);
        val("FB UNPACK",active->unpack);val("FB OPMODE",active->opmode);
        val("PIPE     ",(unsigned)(active-pipes));
        row++;val("RECORDS  ",report.count);val("RAM BANKS",report.banks);
        val("ZERO RAM ",report.zero_banks);val("DYNAMIC  ",report.dynamic_reserved);
        text("RAM is firmware-described, not tested.",white);
        text("Dynamic reservations are not free RAM.",white);
        text("Registers identify a candidate buffer.",white);
        text("Changing pages confirms visible scanout.",white);
        unsigned y=24+row*48;
        for(unsigned i=0;i<4;i++) {uint32_t colors[4]={0xff0000,0x00ff00,0x0000ff,0xffffff};fill(24+i*280,y,280,48,pixel(active,colors[i]));}
        row+=2;text("Expected bars: RED GREEN BLUE WHITE",white);
    } else {
        unsigned start=(index-1)*12, stop=start+12;if(stop>report.count)stop=report.count;
        for(unsigned i=start;i<stop;i++) {
            struct range *v=&report.ranges[i];
            p=hex(b,i,3);p=cat(p,v->kind==1?" RAM ":v->kind==2?" RSV ":v->kind==3?" MAP ":" INIT ");cat(p,v->name);text(b,v->kind==1?green:white);
            val("BASE ",v->base);val("SIZE ",v->size);
        }
    }
    row=49;text("No flash / erase / unlock operations.",white);
    text("Automatic PSCI reset at end of 2 cycles.",white);
}
void hello_main(uint64_t fdt,uint64_t el,uint64_t load) {
    dtb_pa=fdt;load_pa=load;level=el;
    /* Do not render or use guessed hardware if ABL did not supply a valid DTB. */
    if(!fdt || (fdt&7) || fdt>UINT64_MAX-MAX_DTB) fatal();
    uint32_t fault=0,magic=safe_rd32(fdt,&fault);if(fault || magic!=0xedfe0dd0)fatal();
    uint32_t size=__builtin_bswap32(safe_rd32(fdt+4,&fault));
    if(fault || size<40 || size>MAX_DTB || overlaps(fdt,size,load,(uintptr_t)_image_end-load))fatal();
    for(uint32_t i=0;i<size;i+=4) {
        uint32_t v=safe_rd32(fdt+i,&fault);if(fault)fatal();
        for(unsigned j=0;j<4 && i+j<size;j++)blob[i+j]=(uint8_t)(v>>(j*8));
    }
    if(parse_dtb(blob,size,&report))fatal();
#ifdef DIAG_QEMU_TEST
    /* A separately named image exercises entry, BSS, safe loads and FDT parsing.
       It never uses phone display MMIO and is not the phone artifact. */
    if(report.banks) {
        const char *s="MYRON DIAG QEMU: entry/FDT/RAM PASS\n";
        while(*s) *(volatile uint32_t *)0x09000000=(uint32_t)*s++;
    }
    for(;;) __asm__ volatile("wfe");
#endif
    if(!device_ok())fatal();
    find_fb();freq=REG(cntfrq_el0);if(!freq || freq>1000000000)fatal();
    unsigned pages=1+(report.count+11)/12, total=pages*8*2;
    uint64_t begin=REG(cntvct_el0);
    for(unsigned slot=0;slot<pages*2;slot++) {
        page(slot%pages,pages,total-slot*8);
        while((REG(cntvct_el0)-begin)/freq<(uint64_t)(slot+1)*8){}
    }
    fatal();
}
