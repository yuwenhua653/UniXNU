import ctypes as C
import os, random, struct, subprocess, tempfile, unittest
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
be=lambda *v:struct.pack('>'+'I'*len(v),*v)
class Range(C.Structure):
    _fields_=[('base',C.c_uint64),('size',C.c_uint64),('name',C.c_char*32),('kind',C.c_uint)]
class Report(C.Structure):
    _fields_=[('ranges',Range*256),('count',C.c_uint),('banks',C.c_uint),('dynamic_reserved',C.c_uint),('zero_banks',C.c_uint),('dtb_size',C.c_uint32),('crc',C.c_uint32),('pipes',C.c_uint32*10),('splash',C.c_uint64),('splash_size',C.c_uint64),('mdp',C.c_uint64),('panel',C.c_uint),('touch',C.c_uint),('mdp_ok',C.c_uint),('splash_ok',C.c_uint)]
class Pipe(C.Structure):
    _fields_=[(k,C.c_uint32) for k in ('size','addr','stride','fmt','unpack','opmode','faulted')]
def fixture(ac=2,sc=2,zero=False,dynamic=False):
    strings=bytearray(); block=bytearray()
    def node(n):
        block.extend(be(1)+n.encode()+b'\0');block.extend(b'\0'*(-len(block)%4))
    def end():block.extend(be(2))
    def prop(n,v):
        off=len(strings);strings.extend(n.encode()+b'\0');block.extend(be(3,len(v),off)+v);block.extend(b'\0'*(-len(block)%4))
    def num(v,c):return v.to_bytes(c*4,'big')
    node('');prop('#address-cells',be(ac));prop('#size-cells',be(sc))
    node('memory@80000000');prop('reg',num(0x80000000,ac)+num(0 if zero else 0x40000000,sc));end()
    node('reserved-memory');prop('#address-cells',be(ac));prop('#size-cells',be(sc));prop('ranges',b'')
    node('test@80000000');prop('size' if dynamic else 'reg',num(0x1000,sc) if dynamic else num(0x80000000,ac)+num(0x1000,sc));end();end();end();block.extend(be(9))
    reserve=struct.pack('>4Q',0x90000000,0x2000,0,0)
    off=40+len(reserve);total=off+len(block)+len(strings)
    return be(0xd00dfeed,total,off,off+len(block),40,17,16,0,len(strings),len(block))+reserve+block+strings
class Core(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.tmp=tempfile.TemporaryDirectory();lib=Path(cls.tmp.name)/'core.so'
        subprocess.run(['gcc','-shared','-fPIC','-O1','-Wall','-Wextra','-Werror',str(ROOT/'core.c'),'-o',str(lib)],check=True)
        cls.lib=C.CDLL(str(lib));cls.lib.parse_dtb.argtypes=[C.c_void_p,C.c_uint32,C.POINTER(Report)]
        cls.lib.valid_pipe.argtypes=[C.POINTER(Report),C.POINTER(Pipe)]
        cls.lib.pixel.argtypes=[C.POINTER(Pipe),C.c_uint32];cls.lib.pixel.restype=C.c_uint32
    def parse(self,d):
        r=Report();return self.lib.parse_dtb(C.create_string_buffer(d),len(d),C.byref(r)),r
    def test_cells_and_reserved(self):
        for ac,sc in ((1,1),(2,1),(2,2)):
            code,r=self.parse(fixture(ac,sc));self.assertEqual(code,0);self.assertEqual(r.banks,1);self.assertEqual(r.count,3)
            self.assertEqual(r.ranges[1].base,0x80000000);self.assertEqual(r.ranges[2].size,0x1000)
    def test_zero_and_dynamic(self):
        code,r=self.parse(fixture(zero=True,dynamic=True));self.assertEqual(code,0);self.assertEqual(r.banks,0);self.assertEqual(r.zero_banks,1);self.assertEqual(r.dynamic_reserved,1)
    def test_truncated(self):
        d=fixture()
        for n in range(len(d)):self.assertNotEqual(self.parse(d[:n])[0],0)
    def test_header_overlap_and_overflow(self):
        for pos,val in ((8,0xfffffff0),(12,40),(16,41),(32,0xffffffff),(36,0xffffffff)):
            d=bytearray(fixture());struct.pack_into('>I',d,pos,val);self.assertNotEqual(self.parse(bytes(d))[0],0)
    def test_crc(self):
        import zlib
        d=fixture();self.assertEqual(self.parse(d)[1].crc,zlib.crc32(d))
    def test_pixel_gate(self):
        r=Report();r.splash=0xfc800000;r.splash_size=0x2b00000
        p=Pipe((2608<<16)|1200,0xfc800000,4800,0x237ff,0x03020001,0,0)
        self.assertEqual(self.lib.valid_pipe(C.byref(r),C.byref(p)),1)
        self.assertEqual(self.lib.pixel(C.byref(p),0xff0000),0xffff0000)
        for field,v in [('addr',0xfc7ffffc),('addr',0xff2ffffc),('stride',4796),('size',(2656<<16)|1220),('faulted',1),('fmt',p.fmt|(1<<30)),('fmt',p.fmt|(1<<14)),('unpack',0),('opmode',1)]:
            q=Pipe.from_buffer_copy(p);setattr(q,field,v);self.assertEqual(self.lib.valid_pipe(C.byref(r),C.byref(q)),0,(field,v))
    def test_mutations(self):
        rng=random.Random(8850);d=fixture()
        for _ in range(1000):
            v=bytearray(d)
            for _ in range(4):v[rng.randrange(len(v))]=rng.randrange(256)
            self.parse(bytes(v))
    def test_evox_fixture_if_present(self):
        p=os.environ.get('MYRON_EVOX_DTB')
        if not p:self.skipTest('Optional full EvoX DTB not supplied')
        code,r=self.parse(Path(p).read_bytes());self.assertEqual(code,0)
        self.assertEqual((r.panel,r.touch,r.mdp_ok,r.splash_ok),(1,1,1,1));self.assertEqual(r.banks,0)
        self.assertEqual(r.mdp,0x9800000);self.assertEqual(r.splash,0xfc800000)
if __name__=='__main__':unittest.main(verbosity=2)
