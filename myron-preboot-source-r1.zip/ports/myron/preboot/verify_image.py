"""Check boot v4 and arm64 Image bounds; record exact artifact hashes."""
import hashlib, json, struct, sys
from pathlib import Path
p = Path(sys.argv[1]); image = (p/'Image').read_bytes(); boot = (p/'myron-preboot-diag.img').read_bytes()
assert image[56:60] == b'ARM\x64'
size, flags = struct.unpack_from('<QQ', image, 16)
assert len(image) <= size < 8*1024*1024 and flags == 10
magic, kernel, ramdisk, version, header = struct.unpack_from('<8s4I', boot)
assert magic == b'ANDROID!' and kernel == len(image) and ramdisk == 0 and version == 0 and header == 1584
assert struct.unpack_from('<I', boot, 40)[0] == 4
assert struct.unpack_from('<I', boot, 1580)[0] == 0
assert boot[4096:4096+len(image)] == image
assert len(boot) == 4096+((len(image)+4095)//4096)*4096
result = {'format': 'Android boot v4 / arm64 Image', 'image_memory_size': size,
          'phone_tested': False, 'writes_storage': False,
          'sha256': {n: hashlib.sha256((p/n).read_bytes()).hexdigest() for n in ('Image','myron-preboot-diag.img')}}
(p/'build-manifest.json').write_text(json.dumps(result, indent=2)+'\n')
print(json.dumps(result, indent=2))
