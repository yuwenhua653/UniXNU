/* Bounded, allocation-free decoder. No physical accesses in this module. */
#include "core.h"
static uint32_t be32(const uint8_t *p) {
    return (uint32_t)p[0]<<24 | (uint32_t)p[1]<<16 | (uint32_t)p[2]<<8 | p[3];
}
static uint64_t number(const uint8_t *p, unsigned cells) {
    return cells == 1 ? be32(p) : (uint64_t)be32(p)<<32 | be32(p+4);
}
static int eq(const char *a, const char *b) {
    while (*a && *a == *b) { a++; b++; } return *a == *b;
}
static int prefix(const char *a, const char *b) {
    while (*b && *a == *b) { a++; b++; } return !*b;
}
static int string_end(const uint8_t *d, uint32_t p, uint32_t end, uint32_t *next) {
    while (p < end && d[p]) p++;
    if (p == end) return 0;
    *next = p+1; return 1;
}
uint32_t crc32(const uint8_t *p, uint32_t n) {
    uint32_t c = ~0u;
    while (n--) { c ^= *p++; for (unsigned i=0;i<8;i++) c=(c>>1) ^ (0xedb88320u & (0u-(c&1))); }
    return ~c;
}
static int add(struct report *r, const char *name, unsigned kind, uint64_t b, uint64_t s) {
    if (!s) { if (kind==1) r->zero_banks++; return 1; }
    if (b > UINT64_MAX-s || r->count == MAX_RECORDS) return 0;
    struct range *v = &r->ranges[r->count++];
    v->base=b; v->size=s; v->kind=kind;
    unsigned i=0; for (; i<31 && name[i]; i++) v->name[i]=name[i]; v->name[i]=0;
    if (kind==1) r->banks++;
    return 1;
}
struct node {
    const char *name;
    uint32_t ac, sc, pac, psc, reg, len;
    unsigned reserved, memory, child_started, dynamic, disabled, have_reg;
};
int parse_dtb(const uint8_t *d, uint32_t len, struct report *r) {
    uint8_t *clear=(uint8_t *)r;
    for (unsigned i=0;i<sizeof(*r);i++) clear[i]=0;
    if (len<40 || len>MAX_DTB || be32(d)!=0xd00dfeed) return 1;
    uint32_t total=be32(d+4), pos=be32(d+8), str=be32(d+12), res=be32(d+16);
    uint32_t ns=be32(d+32), nt=be32(d+36);
    if (total>len || total<40 || be32(d+20)<17 || be32(d+24)>17 ||
        pos<40 || pos>total || nt>total-pos || str<40 || str>total || ns>total-str ||
        (pos&3) || (res&7) || res<40 || res>total || !nt || !ns) return 2;
    uint32_t end=pos+nt;
    if (!(end<=str || str+ns<=pos)) return 2;
    uint32_t rend=res;
    for (;;) {
        if (rend>total || total-rend<16) return 3;
        uint64_t b=number(d+rend,2), s=number(d+rend+8,2); rend+=16;
        if (!b && !s) break;
        if (!s || !add(r,"memreserve",3,b,s)) return 3;
    }
    if (!(rend<=pos || end<=res) || !(rend<=str || str+ns<=res)) return 3;
    struct node stack[64]; unsigned depth=0, roots=0;
    uint64_t init_start=0, init_end=0; unsigned init_flags=0;
    while (end-pos>=4) {
        uint32_t token=be32(d+pos); pos+=4;
        if (token==1) {
            uint32_t next;
            if (depth==64 || !string_end(d,pos,end,&next)) return 4;
            struct node n={0}; n.name=(const char *)(d+pos); n.ac=2; n.sc=1;
            n.pac=depth ? stack[depth-1].ac : 2; n.psc=depth ? stack[depth-1].sc : 1;
            n.reserved=depth==2 && eq(stack[1].name,"reserved-memory");
            n.memory=depth==1 && (eq(n.name,"memory") || prefix(n.name,"memory@"));
            if (!depth) { if (roots++ || *n.name) return 4; }
            else stack[depth-1].child_started=1;
            if (prefix(n.name,"qcom,mdss_dsi_p11u_")) r->panel=1;
            stack[depth++]=n; pos=(next+3)&~3u;
        } else if (token==2) {
            if (!depth) return 5;
            struct node *n=&stack[depth-1];
            if ((n->memory || n->reserved) && !n->disabled) {
                if (n->reserved && n->dynamic && !n->have_reg) r->dynamic_reserved++;
                if (n->memory && !n->have_reg) return 6;
                unsigned step=(n->pac+n->psc)*4;
                if (n->pac<1 || n->pac>2 || n->psc<1 || n->psc>2 || n->len%step) return 6;
                for (uint32_t j=0;j<n->len;j+=step) {
                    uint64_t b=number(d+n->reg+j,n->pac), s=number(d+n->reg+j+4*n->pac,n->psc);
                    if (!add(r,n->name,n->memory?1:2,b,s)) return 7;
                    if (n->reserved && eq(n->name,"splash_region")) {
                        if (r->splash_ok || n->len!=step) return 7;
                        r->splash=b; r->splash_size=s; r->splash_ok=1;
                    }
                }
            }
            if (prefix(n->name,"qcom,mdss_mdp@")) {
                if (r->mdp_ok || n->pac!=2 || n->psc!=2 || n->len<16) return 8;
                r->mdp=number(d+n->reg,2); r->mdp_ok=1;
            }
            depth--;
        } else if (token==3) {
            if (!depth || end-pos<8) return 9;
            uint32_t size=be32(d+pos), no=be32(d+pos+4), next; pos+=8;
            if (size>end-pos || no>=ns || !string_end(d,str+no,str+ns,&next)) return 9;
            const char *key=(const char *)(d+str+no);
            struct node *n=&stack[depth-1];
            if (n->child_started) return 9;
            if (eq(key,"#address-cells") || eq(key,"#size-cells")) {
                if (size!=4) return 10;
                if (eq(key,"#address-cells")) n->ac=be32(d+pos); else n->sc=be32(d+pos);
            } else if (eq(key,"reg")) {
                if (n->have_reg) return 10;
                n->have_reg=1; n->reg=pos; n->len=size;
            } else if (eq(key,"size")) n->dynamic=1;
            else if (eq(key,"status")) {
                if (!size || d[pos+size-1]) return 10;
                n->disabled=!(eq((const char *)(d+pos),"okay") || eq((const char *)(d+pos),"ok"));
            } else if (eq(key,"compatible")) {
                uint32_t q=pos;
                while (q<pos+size) {
                    if (!string_end(d,q,pos+size,&next)) return 10;
                    if (eq((const char *)(d+q),"focal,touch-spi")) r->touch=1;
                    q=next;
                }
            } else if (eq(key,"qcom,sde-sspp-off") && prefix(n->name,"qcom,mdss_mdp@")) {
                if (size!=40) return 10;
                for (unsigned i=0;i<10;i++) r->pipes[i]=be32(d+pos+4*i);
            } else if (depth==2 && eq(n->name,"chosen") &&
                       (eq(key,"linux,initrd-start") || eq(key,"linux,initrd-end"))) {
                if (size!=4 && size!=8) return 10;
                if (eq(key,"linux,initrd-start")) {init_start=number(d+pos,size/4);init_flags|=1;}
                else {init_end=number(d+pos,size/4);init_flags|=2;}
            }
            pos=(pos+size+3)&~3u;
        } else if (token==4) { /* NOP */ }
        else if (token==9) {
            if (depth || roots!=1) return 11;
            if (init_flags && (init_flags!=3 || init_end<=init_start || !add(r,"initrd",4,init_start,init_end-init_start))) return 11;
            r->dtb_size=total; r->crc=crc32(d,total); return 0;
        } else return 12;
        if (pos>end) return 13;
    }
    return 14;
}
int valid_pipe(const struct report *r, const struct pipe *p) {
    uint32_t w=p->size&65535, h=p->size>>16, stride=p->stride&65535, f=p->fmt;
    if (p->faulted || w!=1200 || h!=2608 || stride<w*4 || stride%4 ||
        p->addr<r->splash || p->addr%4 || (uint64_t)p->addr-r->splash>r->splash_size ||
        (uint64_t)stride*h>r->splash_size-((uint64_t)p->addr-r->splash)) return 0;
    /* Linear, interleaved, tightly packed four 8-bit components. Reject UBWC,
       tiled, YUV, DX/10-bit, rotation and solid fill. Register fields follow
       Qualcomm's sde_hw_sspp_setup_format, not panel DSI bits-per-pixel. */
    if ((f>>30) || ((f>>19)&3) || ((f>>23)&3) || (f&((1u<<11)|(1u<<14)|(1u<<15)|(1u<<22))) ||
        (f&255)!=255 || ((f>>9)&3)!=3 || ((f>>12)&3)!=3 || !(f&(1u<<17)) || (f&(1u<<18)) ||
        (p->opmode&1)) return 0;
    unsigned seen=0;
    for (unsigned i=0;i<4;i++) { unsigned c=(p->unpack>>(i*8))&255; if(c>3 || (seen&(1u<<c))) return 0; seen|=1u<<c; }
    return seen==15;
}
uint32_t pixel(const struct pipe *p, uint32_t rgb) {
    uint32_t c[4]={(rgb>>8)&255,rgb&255,(rgb>>16)&255,255}, v=0;
    for(unsigned i=0;i<4;i++) v|=c[(p->unpack>>(i*8))&3]<<(8*i);
    return v;
}
