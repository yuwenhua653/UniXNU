# MYRON stage-0 bring-up

The `myron-stage0-ci` branch builds the pinned ios-pandora XNU patch series
with `MYRON_STAGE0` hardware guards, then runs that kernel in QEMU with a
static arm64 test program as PID 1. `PANDORA` remains the internal build
configuration name; it is not a claim of Pandora hardware compatibility.

The hardware reference is the official Evolution X MYRON device tree and
prebuilt DTB/DTBO, pinned in `device/source-lock.json`. QEMU uses synthetic
RAM, GIC and timer addresses and a 1200 x 2608 framebuffer. Its success does
not validate physical MYRON RAM, scanout, storage, touch or a complete iOS UI.

`MYRON stage0 XNU and QEMU PID1` runs on pushes to this branch or manually.
The kernel and matching symbols stay in the same macOS job for QEMU.
The artifact includes the build log, kernel/payload hashes, screenshot, decoded
console, CPU state, emulator log and `verification.json`. Kernels and payloads
are not published because the build can link Apple SDK/KDK support libraries. Passing requires
the guest's getpid result to be 1 and at least two userspace heartbeat lines;
an absent panic alone never passes. The verifier does not search the payload
or kernel binary for success strings.

No IPSW, account credentials or captured private phone logs are required.
These outputs are emulator test material, not a phone flash package.

Local reproduction after downloading the kernel artifact:

```sh
git clone https://github.com/dipa-studio/ios-sweet sweet
git -C sweet checkout 425b25102b6a9ee4b68fb2b9ca5d6a086b8a4116
python3 ports/myron/tools/run_qemu.py --sweet sweet --kernel-dir kernel --out qemu-results
```

Linux dependencies: Python 3, qemu-system-aarch64, clang and llvm-nm.
The minimal ADT deliberately omits `/options`: creating an NVRAM service
without a valid CHRP proxy bank can panic; RAM-only PID 1 does not need it.

The GitHub web upload uses `myron-stage0-source.zip` (source files only); the
workflow checks its SHA-256 before extracting `ports/myron/`.
