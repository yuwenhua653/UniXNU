#!/usr/bin/env bash
# Build only, never execute fastboot. Needs a reviewed payload and generated header.
set -euo pipefail
cd "$(dirname "$0")"
out=${OUT:-out}
test -f myron_platform.h || { echo 'Missing measured MYRON platform header; see mkadt_myron.py.' >&2; exit 1; }
test -f "$out/payload.bin" || { echo 'Missing reviewed stage-0 payload.bin; not supplied in R2.' >&2; exit 1; }
mkdir -p "$out"
clang_bin=${CLANG:-clang}
link_bin=${LD_LLD:-ld.lld}
objcopy_bin=${LLVM_OBJCOPY:-llvm-objcopy}
readelf_bin=${LLVM_READELF:-llvm-readelf}
python_bin=${PYTHON:-python3}
flags=(--target=aarch64-none-elf -O2 -ffreestanding -fno-builtin -nostdlib -fno-pic
       -fno-stack-protector -mgeneral-regs-only -mstrict-align -Wall -Wextra -Werror)
if [[ ${MYRON_QEMU_TEST:-0} == 1 ]]; then flags+=(-DMYRON_QEMU_TEST=1); fi
"$clang_bin" "${flags[@]}" -c start.S -o "$out/start.o"
"$clang_bin" "${flags[@]}" "-DPAYLOAD=\"$out/payload.bin\"" -c payload.S -o "$out/payload.o"
"$clang_bin" "${flags[@]}" -c loader.c -o "$out/loader.o"
"$readelf_bin" -r "$out/loader.o" > "$out/relocations.txt"
if grep -q R_AARCH64_ABS "$out/relocations.txt"; then echo 'Absolute C relocation rejected' >&2; exit 1; fi
"$link_bin" -T loader.ld --build-id=none "$out/start.o" "$out/loader.o" "$out/payload.o" -o "$out/loader.elf"
"$objcopy_bin" -O binary "$out/loader.elf" "$out/Image"
"$python_bin" - "$out/Image" <<'PY'
import struct,sys
from pathlib import Path
b=Path(sys.argv[1]).read_bytes()
assert b[0x38:0x3c]==b'ARM\x64', 'missing arm64 header'
assert struct.unpack_from('<Q',b,16)[0]==len(b), 'image_size mismatch'
PY
name=myron-stage0-candidate.img
if [[ ${MYRON_QEMU_TEST:-0} == 1 ]]; then name=myron-qemu-only.img; fi
"$python_bin" ../../tools/mkbootimg_v4.py "$out/Image" "$out/$name"
"$python_bin" ../../tools/bootimg_info.py "$out/$name"
echo "Built $out/$name. Not boot-tested. No phone command executed."
