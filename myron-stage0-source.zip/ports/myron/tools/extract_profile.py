"""Extract MYRON hardware facts from an already merged official DTB or live FDT."""
import argparse
import hashlib
import json
from pathlib import Path
from fdt import load


def extract(path):
    root = load(path)
    nodes = {n.path: n for n in root.walk() if not n.path.startswith('/__')}
    def compatible(name):
        found = [n for n in nodes.values() if name in n.strings('compatible')]
        if len(found) != 1:
            raise ValueError(f'expected one {name}, got {len(found)}')
        return found[0]
    def fact(n, key):
        return {'path': n.path, 'property': key, 'cells': n.cells(key)}
    def gpio(n, key):
        v = n.cells(key)
        if len(v) != 3 or v[0] not in root.phandles:
            raise ValueError(f'invalid GPIO {n.path}:{key}')
        return {'controller': root.phandles[v[0]].path, 'pin': v[1], 'flags': v[2], 'property': key}
    model = root.strings('model')[0]
    # libfdt applies fragments, not the overlay header's root model/board IDs.
    # The merged base therefore still reports Canoe. Require Myron panel and
    # touch markers; provenance of the base/overlay is recorded separately.
    if not any('mdss_dsi_p11u_' in n.name for n in nodes.values()):
        raise ValueError('Myron p11u panel definitions missing')
    cpu = [n for n in nodes.values() if n.strings('device_type') == ['cpu']]
    gic = compatible('arm,gic-v3')
    timer = compatible('arm,armv8-timer')
    psci = compatible('arm,psci-1.0')
    ufs = compatible('qcom,ufshc')
    touch = compatible('focal,touch-spi')
    mdp = compatible('qcom,sde-kms')
    splash = nodes['/reserved-memory/splash_region']
    display = nodes['/soc/qcom,dsi-display-primary']
    default_panel = root.phandles[display.cells('qcom,dsi-default-panel')[0]]
    panel_nodes = [root.phandles[ph] for ph in touch.cells('panel')]
    panels = []
    for panel in panel_nodes:
        timings = []
        for t in panel.walk():
            if 'qcom,mdss-dsi-panel-width' in t.props:
                timings.append({'path': t.path, 'width': t.cells('qcom,mdss-dsi-panel-width')[0],
                                'height': t.cells('qcom,mdss-dsi-panel-height')[0],
                                'hz': t.cells('qcom,mdss-dsi-panel-framerate')[0]})
        panels.append({'path': panel.path, 'type': panel.strings('qcom,mdss-dsi-panel-type')[0],
                       'dsi_bpp': panel.cells('qcom,mdss-dsi-bpp'), 'timings': timings,
                       'backlight_max': panel.cells('qcom,mdss-dsi-bl-max-level')})
    myron_panels = [p for p in panels if 'mdss_dsi_p11u_' in p['path']]
    if not myron_panels or any((t['width'], t['height']) != (1200,2608) for p in myron_panels for t in p['timings']):
        raise ValueError('unexpected Myron panel dimensions')
    banks = [pair for n in nodes.values() if n.strings('device_type') == ['memory'] for pair in n.reg()]
    fixed, dynamic = [], []
    for n in nodes['/reserved-memory'].children:
        if 'reg' in n.props:
            fixed.extend({'path': n.path, 'base': a, 'size': s} for a, s in n.reg())
        elif 'size' in n.props:
            dynamic.append({'path': n.path, 'size_cells': n.cells('size'),
                            'alloc_ranges_cells': n.cells('alloc-ranges')})
    iommus = ufs.cells('iommus')
    smmu = root.phandles[iommus[0]]
    supply_nodes = {key: root.phandles[touch.cells(key)[0]] for key in ('avdd-supply', 'iovdd-supply')}
    supplies = {k: {'path': n.path, 'name': n.strings('regulator-name'),
                    'gpio': gpio(n, 'gpio') if 'gpio' in n.props else None}
                for k, n in supply_nodes.items()}
    return {
        'schema': 1, 'device': 'myron', 'model': model,
        'dtb_sha256': hashlib.sha256(Path(path).read_bytes()).hexdigest(),
        'evidence_class': 'device-tree-description-not-runtime-validation',
        'cpu': {'mpidrs': [n.reg()[0][0] for n in cpu], 'paths': [n.path for n in cpu],
                'psci_method': psci.strings('method')[0]},
        'gic': {'path': gic.path, 'reg': gic.reg(), 'redistributor_stride': int.from_bytes(gic.props['redistributor-stride'], 'big')},
        'timer': {'path': timer.path, 'frequency': timer.cells('clock-frequency')[0],
                  'interrupts': timer.cells('interrupts'), 'virtual_intid': timer.cells('interrupts')[7]+16},
        'ufs': {'path': ufs.path, 'reg': ufs.reg(), 'reg_names': ufs.strings('reg-names'),
                'iommu_specifier': iommus[1:], 'smmu_path': smmu.path, 'smmu_reg': smmu.reg(),
                'handoff_state': 'unknown', 'enabled_in_stage0': False},
        'display': {'default_panel': default_panel.path, 'panel_candidates': panels,
                    'splash': {'path': splash.path, 'reg': splash.reg()}, 'mdp_reg': mdp.reg(),
                    'sspp_offsets': mdp.cells('qcom,sde-sspp-off'),
                    'width': 1200, 'height': 2608, 'framebuffer_base': None,
                    'framebuffer_stride': None, 'framebuffer_format': None,
                    'note': 'DSI 30bpp does not determine framebuffer format. Splash reservation is not proof of active scanout.'},
        'touch': {'path': touch.path, 'compatible': touch.strings('compatible'),
                  'bus_path': touch.parent.path, 'bus_reg': touch.parent.reg(),
                  'spi_max_hz': touch.cells('spi-max-frequency')[0],
                  'irq': gpio(touch, 'focaltech,irq-gpio'), 'reset': gpio(touch, 'focaltech,reset-gpio'),
                  'max_x': touch.cells('focaltech,max-x')[0], 'max_y': touch.cells('focaltech,max-y')[0],
                  'display_coords': touch.cells('focaltech,display-coords'),
                  'super_resolution_factor': touch.cells('focaltech,super-resolution-factors')[0],
                  'supplies': supplies, 'enabled_in_stage0': False,
                  'note': 'FocalTech protocol required; Pandora Synaptics TCM driver must not run.'},
        'keys': {'volup': gpio(nodes['/soc/gpio_keys/vol_up'], 'gpios'), 'enabled_in_stage0': False},
        'memory': {'banks': banks, 'fixed_reserved': fixed, 'dynamic_reserved': dynamic,
                   'fdt_memreserve': root.reservations,
                   'usable_bank_information_present': any(s > 0 for _, s in banks),
                   'note': 'Static prebuilt memory/reg is a bootloader placeholder; do not copy Pandora RAM constants.'},
        'blocking_runtime_facts': ['bootloader-filled RAM banks and reserved map',
                                   'active framebuffer address, stride and format',
                                   'ABL placement and temporary boot handoff']}


if __name__ == '__main__':
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('dtb', type=Path)
    p.add_argument('--out', type=Path, required=True)
    args = p.parse_args()
    result = extract(args.dtb)
    args.out.parent.mkdir(parents=True, exist_ok=True)
    args.out.write_text(json.dumps(result, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')
    print(f'Wrote {args.out}; RAM banks populated: {result["memory"]["usable_bank_information_present"]}')
