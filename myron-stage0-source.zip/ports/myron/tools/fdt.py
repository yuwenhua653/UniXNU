"""Read FDT v17 without external packages; fail closed on malformed input."""
import struct
from pathlib import Path


class Node:
    def __init__(self, name, parent=None):
        self.name, self.parent = name, parent
        self.props, self.children = {}, []

    @property
    def path(self):
        return '/' if self.parent is None else self.parent.path.rstrip('/') + '/' + self.name

    def walk(self):
        yield self
        for child in self.children:
            yield from child.walk()

    def strings(self, key):
        return self.props.get(key, b'').rstrip(b'\0').decode('utf-8').split('\0')

    def cells(self, key):
        data = self.props.get(key, b'')
        if len(data) % 4:
            raise ValueError(f'{self.path}:{key}: invalid cell length')
        return list(struct.unpack('>' + 'I' * (len(data) // 4), data))

    def reg(self):
        if self.parent is None:
            return []
        ac = (self.parent.cells('#address-cells') or [2])[0]
        sc = (self.parent.cells('#size-cells') or [1])[0]
        if ac not in (1, 2) or sc not in (0, 1, 2):
            raise ValueError('unsupported reg cell format')
        values = self.cells('reg')
        step = ac + sc
        if len(values) % step:
            raise ValueError(f'{self.path}: incomplete reg')
        def number(v):
            result = 0
            for cell in v:
                result = result << 32 | cell
            return result
        return [[number(values[i:i+ac]), number(values[i+ac:i+step])]
                for i in range(0, len(values), step)]


def load(path):
    data = Path(path).read_bytes()
    if len(data) < 40:
        raise ValueError('FDT header truncated')
    magic, total, os, ost, ores, ver, compat, _, ns, nt = struct.unpack_from('>10I', data)
    if magic != 0xd00dfeed or not 40 <= total <= len(data) or ver < 17 or compat > 17:
        raise ValueError('invalid or unsupported FDT header')
    if any(off < 40 or off + size > total for off, size in [(os, nt), (ost, ns)]):
        raise ValueError('FDT section outside bounds')
    data = data[:total]
    strings = data[ost:ost+ns]
    pos, end, stack, root = os, os+nt, [], None
    def cstr(buf, start, limit):
        stop = buf.find(b'\0', start, limit)
        if stop < 0:
            raise ValueError('unterminated FDT string')
        return buf[start:stop].decode('utf-8'), stop+1
    while pos + 4 <= end:
        tok = struct.unpack_from('>I', data, pos)[0]
        pos += 4
        if tok == 1:
            name, pos = cstr(data, pos, end)
            pos = (pos+3) & ~3
            if len(stack) >= 128:
                raise ValueError('excessive FDT depth')
            n = Node(name, stack[-1] if stack else None)
            if stack:
                stack[-1].children.append(n)
            elif root is not None:
                raise ValueError('multiple FDT roots')
            else:
                root = n
            stack.append(n)
        elif tok == 2:
            if not stack:
                raise ValueError('unbalanced FDT end node')
            stack.pop()
        elif tok == 3:
            if not stack or pos + 8 > end:
                raise ValueError('invalid FDT property')
            size, nameoff = struct.unpack_from('>II', data, pos)
            pos += 8
            if pos+size > end or nameoff >= len(strings):
                raise ValueError('FDT property outside bounds')
            key, _ = cstr(strings, nameoff, len(strings))
            if key in stack[-1].props:
                raise ValueError('duplicate FDT property')
            stack[-1].props[key] = data[pos:pos+size]
            pos = (pos+size+3) & ~3
        elif tok == 4:
            pass
        elif tok == 9:
            if stack or root is None:
                raise ValueError('incomplete FDT tree')
            break
        else:
            raise ValueError(f'invalid FDT token {tok}')
    else:
        raise ValueError('missing FDT end marker')
    root.phandles = {}
    for n in root.walk():
        ph = n.cells('phandle') or n.cells('linux,phandle')
        if ph:
            if ph[0] in root.phandles:
                raise ValueError('duplicate phandle')
            root.phandles[ph[0]] = n
    root.reservations = []
    if ores < 40 or ores % 8:
        raise ValueError('invalid reservation offset')
    while ores+16 <= total:
        a, size = struct.unpack_from('>QQ', data, ores)
        ores += 16
        if a == size == 0:
            break
        root.reservations.append([a, size])
    else:
        raise ValueError('unterminated FDT reservations')
    return root
