"""Generate a RAM-only MYRON XNU stage-0 ADT and matching loader header.

Phone mode requires a bootloader-filled FDT and explicit measured framebuffer facts.
--qemu emits a synthetic test artifact; it is never a phone boot configuration.
"""
import argparse
import json
import os
import struct
from pathlib import Path
from extract_profile import extract


def u32(*v): return struct.pack('<'+'I'*len(v), *v)
def u64(*v): return struct.pack('<'+'Q'*len(v), *v)
def cstr(s): return s.encode()+b'\0'


def node(name, props=None, children=None):
    props = {'name': cstr(name), **(props or {})}
    children = children or []
    data = u32(len(props), len(children))
    for key, value in props.items():
        kb = key.encode()
        if len(kb) > 31:
            raise ValueError('ADT property name too long')
        data += kb.ljust(32, b'\0') + u32(len(value)) + value + b'\0'*(-len(value) % 4)
    return data + b''.join(children)


def check_ram(profile, base, size):
    if base < 0 or size < 256*1024*1024 or base % 0x200000 or size % 0x200000:
        raise ValueError('RAM requires 2 MiB alignment and at least 256 MiB')
    end = base+size
    if end > 1 << 36:
        raise ValueError('stage-0 RAM must fit the conservative 36-bit range')
    banks = profile['memory']['banks']
    if not any(s and a <= base and end <= a+s for a, s in banks):
        raise ValueError('RAM not contained in a populated bootloader memory bank; static DTB is insufficient')
    reserved = [(r['base'], r['size']) for r in profile['memory']['fixed_reserved']]
    reserved += profile['memory']['fdt_memreserve']
    for a, s in reserved:
        if s and max(a, base) < min(a+s, end):
            raise ValueError(f'RAM intersects reserved memory at {a:#x}')


def check_framebuffer(profile, fb):
    if fb.get('measurement') != 'bootloader-handoff' or not fb.get('evidence'):
        raise ValueError('framebuffer requires bootloader-handoff measurement and evidence reference')
    if fb.get('format') != 'ARGB8888':
        raise ValueError('stage-0 renderer currently supports measured ARGB8888 only')
    if (fb.get('width'), fb.get('height')) != (1200, 2608):
        raise ValueError('framebuffer dimensions do not match MYRON')
    base, stride = fb['base'], fb['stride']
    if base % 4 or stride % 4 or not 4800 <= stride <= 65536:
        raise ValueError('invalid framebuffer base/stride')
    size = stride*fb['height']
    if not any(a <= base and base+size <= a+s for a, s in profile['display']['splash']['reg']):
        raise ValueError('framebuffer exceeds splash reservation')


def build(profile, base, size, fb, qemu=False):
    check_ram(profile, base, size)
    if not qemu:
        check_framebuffer(profile, fb)
    cpus = profile['cpu']['mpidrs'][:1] if qemu else profile['cpu']['mpidrs']
    timebase = profile['timer']['frequency']
    cpu_nodes = [node(f'cpu{i}', {'device_type': cstr('cpu'),
        'compatible': cstr('qcom,sm8850-cpu')+cstr('ARM,v8'), 'reg': u32(mpidr),
        'cpu-id': u32(i), 'cluster-id': u32(0), 'cluster-type': u32(0),
        'die-cluster-id': u32(0), 'cluster-core-id': u32(i), 'l2-cache-id': u32(i),
        'l3-cache-id': u32(0), 'state': cstr('running' if i==0 else 'stopped'),
        'timebase-frequency': u32(timebase), 'fixed-frequency': u32(timebase),
        'clock-frequency': u32(1000000000), 'bus-frequency': u32(100000000),
        'memory-frequency': u32(1866000000), 'peripheral-frequency': u32(timebase)})
        for i, mpidr in enumerate(cpus)]
    soc = 0x1000000
    gicregs = [v for a,s in profile['gic']['reg'] for v in [a-soc,s]]
    panic_size = 0x100000
    return node('device-tree', {'compatible': cstr('xiaomi,myron')+cstr('qcom,sm8850')+cstr('AppleARM'),
        'model': cstr('MYRON-XNU-STAGE0'), 'target-type': cstr('MYRON'),
        'device_type': cstr('bootrom')}, [
        node('chosen', {'dram-base': u64(base), 'dram-size': u64(size-panic_size),
            'random-seed': os.urandom(64), 'debug-enabled': u32(1),
            'firmware-version': cstr('myron-stage0-qemu' if qemu else 'myron-stage0'),
            'embedded-panic-log-size': u32(panic_size)}, [node('memory-map')]),
        node('cpus', {'#address-cells': u32(1), '#size-cells': u32(0)}, cpu_nodes),
        node('arm-io', {'device_type': cstr('sweet-io'), 'compatible': cstr('sweet-io')+cstr('arm-io'),
            '#address-cells': u32(2), '#size-cells': u32(2),
            'ranges': u64(0,soc,0x100000000-soc)}, [
                node('gic', {'compatible': cstr('arm,gic-v3'), 'interrupt-controller': b'',
                    'virtual-timer-intid': u32(profile['timer']['virtual_intid']), 'reg': u64(*gicregs)}),
                node('wdt', {'no-pmu': u32(1)})]),
        node('sweet-fbcon', {'reg': u64(fb['base'],fb['stride']*fb['height']),
            'width': u32(fb['width']), 'height': u32(fb['height']), 'stride': u32(fb['stride'])}),
        node('pram', {'reg': u64(base+size-panic_size,panic_size)}),
        node('defaults')])


def header(base,size,fb,qemu=False):
    return ('/* Generated together with MYRON stage-0 ADT. Not a runtime discovery result. */\n'
        '#pragma once\n'+('#ifndef MYRON_QEMU_TEST\n#error QEMU_profile_is_not_a_phone_configuration\n#endif\n' if qemu else '')+''.join(f'#define {name} {value:#x}ULL\n' for name,value in [
        ('FB',fb['base']),('FB_SIZE',fb['stride']*fb['height']),('FB_W',fb['width']),
        ('FB_H',fb['height']),('FB_STRIDE',fb['stride']),('RAM_LO',base),('RAM_HI',base+size)]))


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--profile',type=Path,required=True)
    p.add_argument('--runtime-dtb',type=Path)
    p.add_argument('--framebuffer',type=Path)
    p.add_argument('--ram-base',type=lambda x:int(x,0))
    p.add_argument('--ram-size',type=lambda x:int(x,0))
    p.add_argument('--qemu',action='store_true')
    p.add_argument('--out',type=Path,required=True)
    a=p.parse_args()
    profile=json.loads(a.profile.read_text(encoding='utf-8'))
    if profile.get('device')!='myron': p.error('MYRON profile required')
    try:
        if a.qemu:
            if any(x is not None for x in [a.runtime_dtb,a.framebuffer,a.ram_base,a.ram_size]):
                p.error('--qemu cannot be combined with phone runtime inputs')
            base,size=0xb0000000,0x40000000
            profile['memory']={'banks':[[base,size]],'fixed_reserved':[],'fdt_memreserve':[]}
            profile['gic']['reg']=[[0x8000000,0x10000],[0x80a0000,0x200000]]
            profile['timer']['frequency']=62500000
            fb={'base':0x9c000000,'width':1200,'height':2608,'stride':4800}
        else:
            if not all(x is not None for x in [a.runtime_dtb,a.framebuffer,a.ram_base,a.ram_size]):
                p.error('phone ADT requires --runtime-dtb, --framebuffer, --ram-base, --ram-size; no guessed defaults')
            live=extract(a.runtime_dtb)
            if live['cpu']['mpidrs']!=profile['cpu']['mpidrs'] or live['gic']['reg']!=profile['gic']['reg']:
                p.error('live FDT differs from reviewed CPU/GIC profile')
            profile=live
            base,size=a.ram_base,a.ram_size
            fb=json.loads(a.framebuffer.read_text(encoding='utf-8'))
        data=build(profile,base,size,fb,a.qemu)
    except (ValueError,KeyError) as e:
        p.error(str(e))
    if a.out.exists(): p.error('output directory already exists; choose a new directory')
    a.out.mkdir(parents=True)
    (a.out/'myron-stage0.adt').write_bytes(data)
    (a.out/'myron_platform.h').write_text(header(base,size,fb,a.qemu),encoding='utf-8')
    (a.out/'generation.json').write_text(json.dumps({'mode':'qemu-only' if a.qemu else 'phone-candidate',
        'compiled':False,'boot_tested':False,'ram_base':base,'ram_size':size,'framebuffer':fb,
        'storage_driver':False,'touch_driver':False},indent=2)+'\n',encoding='utf-8')
    print(f'Generated {len(data)} byte ADT in {a.out}; no boot image generated.')


if __name__=='__main__': main()
