"""Prepare a separate MYRON stage-0 source tree from the pinned ios-pandora checkout.

Does not run a build, touch a phone, or edit the input checkout.
PANDORA remains the internal MACHINE_CONFIG to reuse the existing 4K/SMP config;
MYRON_STAGE0 distinguishes this build and its hardware guards.
"""
import argparse
import hashlib
import json
import re
import shutil
import subprocess
from pathlib import Path

PIN='d338ef09c93ba7e69d03e997478fe3ad3acda309'


def replace_once(text, before, after):
    if text.count(before)!=1:
        raise ValueError('upstream source context changed: '+before[:70])
    return text.replace(before,after,1)


def prepare(src,out):
    src,out=src.resolve(),out.resolve()
    if out.exists() or src==out or src in out.parents:
        raise ValueError('use a new output directory outside the upstream checkout')
    sha=subprocess.check_output(['git','-C',str(src),'rev-parse','HEAD'],text=True).strip()
    dirty=subprocess.check_output(['git','-C',str(src),'status','--porcelain'],text=True).strip()
    if sha!=PIN or dirty:
        raise ValueError('requires a clean ios-pandora checkout at '+PIN)
    out.mkdir(parents=True)
    for name in ['xnu','shim/loader','tools/mkbootimg_v4.py','tools/bootimg_info.py','.github/workflows/xnu.yml']:
        source,target=src/name,out/name
        target.parent.mkdir(parents=True,exist_ok=True)
        if source.is_dir(): shutil.copytree(source,target)
        else: shutil.copy2(source,target)
    patchdir=out/'xnu/patches'
    removed=[]
    for p in sorted(patchdir.glob('*.patch')):
        if int(p.name[:4])>127:
            removed.append(p.name)
            p.unlink()
        else:
            # Some upstream patches contain non-UTF-8 vendor comments. Preserve
            # every byte while editing only ASCII configuration tokens.
            text=p.read_bytes().decode('latin-1')
            text=text.replace('-DPANDORA=1','-DPANDORA=1 -DMYRON_STAGE0=1')
            if p.name.startswith('0110-'):
                text=replace_once(text,"'xiaomi,pandora'","'xiaomi,myron'")
            p.write_bytes(text.encode('latin-1'))
    guard=Path(__file__).resolve().parents[1]/'patches/0128-myron-stage0-hardware-guards.patch'
    shutil.copy2(guard,patchdir/guard.name)
    # Reconstruct these new upstream drivers and apply the entire retained patch
    # series. This verifies real hunk application, not just patch syntax.
    check=out/'source-check'
    check.mkdir()
    include=['bsd/dev/sweet_ufs.c','bsd/dev/fuxi_touch.c','bsd/dev/fuxi_keys.c','bsd/dev/fuxi_wlan.c']
    for patch in sorted(patchdir.glob('*.patch')):
        subprocess.run(['git','apply']+['--include='+p for p in include]+[str(patch)],cwd=check,check=True)
    for path in include:
        if '#if defined(MYRON_STAGE0)' not in (check/path).read_text():
            raise ValueError('missing driver guard: '+path)
    loader=out/'shim/loader/loader.c'
    text=loader.read_text()
    start=text.index('#define FB ')
    stop=text.index('#define BOOT_LINE_LENGTH',start)
    text=text[:start]+'/* Generated from reviewed runtime inputs; no Pandora RAM defaults. */\n#include "myron_platform.h"\n\n'+text[stop:]
    text=replace_once(text,'return a >= RAM_LO && n <= RAM_HI - a;',
                     'return a >= RAM_LO && a <= RAM_HI && n <= RAM_HI - a;')
    text=text.replace('kernel RAM outside the clean 0x8c0000000 range','kernel RAM outside the MYRON approved range')
    text=replace_once(text,'line("PANDORA", "loader v1 - nothing is written to storage", GREEN);',
                     'line("MYRON", "stage0 - RAM disk only", GREEN);')
    # Require complete segment table before dereferencing it. Avoid addition wrap.
    text=replace_once(text,'const struct payload *p = (const struct payload *)(uintptr_t)pl;',
        'if (pl_end < pl || pl_end - pl < sizeof(struct payload))\n\t\treturn "truncated payload";\n'
        '\tconst struct payload *p = (const struct payload *)(uintptr_t)pl;')
    text=replace_once(text,'p->nsegs == 0 || p->nsegs > 64)',
        'p->nsegs == 0 || p->nsegs > 64 ||\n'
        '\t    p->nsegs > (pl_end - pl - sizeof(struct payload)) / sizeof(struct payload_seg))')
    text=replace_once(text,'s->file_off + s->file_size > pl_end - pl)',
        's->file_off > pl_end - pl || s->file_size > pl_end - pl - s->file_off)')
    text=replace_once(text,'p->adt_off + p->adt_size > pl_end - pl)',
        'p->adt_off > pl_end - pl || p->adt_size > pl_end - pl - p->adt_off)')
    # Original rounded copy read up to seven bytes past the declared segment.
    text=replace_once(text,'for (uint64_t i = 0; i < (n + 7) / 8; i++)\n\t\td[i] = s[i];',
        'for (uint64_t i = 0; i < n / 8; i++)\n\t\td[i] = s[i];\n'
        '\tvolatile unsigned char *db = (volatile unsigned char *)(uintptr_t)dst;\n'
        '\tvolatile const unsigned char *sb = (volatile const unsigned char *)(uintptr_t)src;\n'
        '\tfor (uint64_t i = (n / 8) * 8; i < n; i++) db[i] = sb[i];')
    text=replace_once(text,'uint64_t done = (s->file_size + 7) & ~7ull;', 'uint64_t done = s->file_size;')
    text=replace_once(text,'volatile uint64_t *d = (volatile uint64_t *)(uintptr_t)dst;\n\tfor (uint64_t i = 0; i < n / 8; i++)\n\t\td[i] = 0;',
        'volatile unsigned char *d = (volatile unsigned char *)(uintptr_t)dst;\n'
        '\tfor (uint64_t i = 0; i < n; i++) d[i] = 0;')
    loader.write_text(text)
    shutil.copy2(Path(__file__).with_name('build_loader.sh'),out/'shim/loader/build.sh')
    # No header is installed: generating one requires runtime facts or --qemu.
    workflow=out/'.github/workflows/xnu.yml'
    text=workflow.read_text().replace('name: xnu\n','name: myron-xnu-stage0\n',1)
    text=text.replace('PANDORA = Xiaomi 17 Pro, 4 KiB pages; FUXI / SWEET also build',
                      'PANDORA = internal 4K config with MYRON_STAGE0 guards; leave unchanged')
    workflow.write_text(text)
    receipt={'upstream_commit':sha,'scope':'MYRON RAM-only source preparation',
        'retained_upstream_patch_max':127,'removed_later_patches':removed,
        'guard_patch_sha256':hashlib.sha256(guard.read_bytes()).hexdigest(),
        'driver_patch_application':'passed','full_xnu_build':'not_run','phone_test':'not_run',
        'boot_image':'not_generated','machine_config':'PANDORA','variant_macro':'MYRON_STAGE0',
        'remaining':['Generate loader header from measured runtime inputs',
                     'Full XNU build and QEMU PID1 test','Review payload and loader before phone execution']}
    (out/'myron-source-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
    (out/'xnu/README.md').write_text(
        '# MYRON stage-0 XNU patches\n\n'
        'Prepared from ios-pandora '+PIN+'. Retains upstream patches 0001–0127, '
        'adds MYRON_STAGE0 guards in local 0128, and changes platform match to xiaomi,myron.\n\n'
        'MACHINE_CONFIG remains PANDORA to reuse its 4K/SMP configuration. '
        'This is RAM-only bring-up, not a complete iOS port. See ../myron-source-receipt.json '
        'and the package README.txt. Full XNU compilation and boot tests have not run.\n',encoding='utf-8')
    return receipt


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--upstream',type=Path,required=True)
    p.add_argument('--out',type=Path,required=True)
    a=p.parse_args()
    try: result=prepare(a.upstream,a.out)
    except (ValueError,subprocess.CalledProcessError) as e: p.error(str(e))
    print(json.dumps(result,indent=2))
