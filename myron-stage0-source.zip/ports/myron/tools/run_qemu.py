#!/usr/bin/env python3
"""Build the static PID1 probe, boot the compiled kernel, and check guest output."""
import argparse
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import sys

SWEET_SHA = '425b25102b6a9ee4b68fb2b9ca5d6a086b8a4116'
HERE = Path(__file__).resolve().parent


def run(*args):
    subprocess.run([str(a) for a in args], check=True)


def verify(screen, decoded):
    pid1 = '*** MYRON userspace: init running as PID 1 ***' in screen
    heartbeats = screen.count('MYRON init: still alive')
    panic = 'panic(cpu ' in screen or 'SWEET EARLY PANIC:' in screen
    passed = (pid1 and heartbeats >= 2 and not panic
              and decoded.get('status') == 'no_panic_observed'
              and decoded.get('unknown_glyphs') == 0)
    return {'passed': passed, 'pid1_observed': pid1,
            'heartbeat_count': heartbeats, 'panic_observed': panic,
            'decoded_screen': decoded,
            'scope': 'QEMU single-CPU userspace smoke test; no physical phone claim'}


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--sweet', required=True, type=Path)
    ap.add_argument('--kernel-dir', required=True, type=Path)
    ap.add_argument('--out', required=True, type=Path)
    ap.add_argument('--seconds', type=int, default=120)
    a = ap.parse_args()
    if a.out.exists():
        ap.error('use a new output directory to exclude stale evidence')
    sweet = a.sweet.resolve()
    sha = subprocess.check_output(['git', '-C', str(sweet), 'rev-parse', 'HEAD'], text=True).strip()
    dirty = subprocess.check_output(['git', '-C', str(sweet), 'status', '--porcelain'], text=True).strip()
    if sha != SWEET_SHA or dirty:
        ap.error('requires clean ios-sweet at ' + SWEET_SHA)
    kernel = (a.kernel_dir / 'kernel.development.pandora').resolve()
    if not kernel.is_file():
        ap.error('compiled kernel.development.pandora missing')
    a.out.mkdir(parents=True)
    out = a.out.resolve()
    result = {'passed': False, 'scope': 'QEMU only'}
    try:
        run(sys.executable, HERE / 'mkadt_myron.py', '--profile',
            HERE.parent / 'device/myron-evox-profile.json', '--qemu', '--out', out / 'adt')
        init_source = (sweet / 'tools/sweet-init.S').read_text().replace('SWEET', 'MYRON')
        (out / 'myron-init.S').write_text(init_source)
        run('clang', '-target', 'arm64-apple-ios16.0', '-c', out / 'myron-init.S', '-o', out / 'myron-init.o')
        run(sys.executable, sweet / 'tools/mkinit.py', out / 'myron-init.o', out / 'myron-init')

        # Keep the pinned upstream tree clean. Patch a tool copy with the same
        # lowest-segment rule used by ios-pandora's qemu_run.sh.
        tool_dir = out / 'payload-tools'
        tool_dir.mkdir()
        (tool_dir / 'adt.py').write_bytes((sweet / 'tools/adt.py').read_bytes())
        payload_code = (sweet / 'tools/mkpayload.py').read_text()
        before = "virt_base = text['vmaddr'] & ~(0x2000000 - 1)"
        assert payload_code.count(before) == 1
        payload_code = payload_code.replace(before, "virt_base = min(s['vmaddr'] for s in segs) & ~(0x2000000 - 1)")
        (tool_dir / 'mkpayload.py').write_text(payload_code)
        run(sys.executable, tool_dir / 'mkpayload.py', kernel, out / 'adt/myron-stage0.adt',
            out / 'payload.bin', '--ramdisk', out / 'myron-init', '--cmdline',
            'debug=0xc serial=3 cpus=1 keepsyms=1 -enable_kprintf_spam -noprogress rd=md0')

        # Import the pinned runner so boot_args, capture and glyph decoding all
        # use the same MYRON dimensions. No phone loader or phone addresses.
        spec = importlib.util.spec_from_file_location('qemu_sweet', sweet / 'tools/qemu-sweet.py')
        emulator = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(emulator)
        emulator.FB_BASE, emulator.FB_W, emulator.FB_H = 0x9c000000, 1200, 2608
        emulator.FB_STRIDE = 4800
        candidates = sorted(a.kernel_dir.resolve().rglob('*unstripped*')) + [kernel]
        symbols = None
        for candidate in candidates:
            if not candidate.is_file():
                continue
            nm = subprocess.run(['llvm-nm', '--defined-only', str(candidate)], capture_output=True, text=True)
            if nm.returncode == 0 and sum(line.split()[-1:] == ['_iso_font'] for line in nm.stdout.splitlines()) == 1:
                symbols = candidate
                break
        if symbols is None:
            raise RuntimeError('matching kernel _iso_font symbol missing; cannot verify guest console')
        sys.argv = ['qemu-sweet.py', str(out / 'payload.bin'), str(out / 'boot'),
                    '--secs', str(a.seconds), '--kernel', str(symbols), '--fail-on-panic']
        emulator_rc = emulator.main()
        decoded = json.loads((out / 'boot/result.json').read_text())
        screen = (out / 'boot/fb.txt').read_text()
        result = verify(screen, decoded)
        result['emulator_returncode'] = emulator_rc
        result['passed'] = result['passed'] and emulator_rc == 0
        result['kernel_sha256'] = hashlib.sha256(kernel.read_bytes()).hexdigest()
        result['payload_sha256'] = hashlib.sha256((out / 'payload.bin').read_bytes()).hexdigest()
        result['sweet_commit'] = sha
        result['workflow_commit'] = os.environ.get('GITHUB_SHA')
        print(screen)
    except Exception as exc:
        result['error'] = repr(exc)
        raise
    finally:
        (out / 'verification.json').write_text(json.dumps(result, indent=2) + '\n')
        print(json.dumps(result, indent=2))
    return 0 if result['passed'] else 1


if __name__ == '__main__':
    sys.exit(main())
